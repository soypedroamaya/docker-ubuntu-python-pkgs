from .bunit.concept.domain import calculator

_calc = calculator

sumx = _calc.sum_numbers
resx = _calc.rest_numbers
